#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

class Tariff {
    int cost, number_subscribers;
    string title;
public:
    Tariff(): cost(0), number_subscribers(0) {};
    Tariff(string n, int c, int num): title(n), cost(c), number_subscribers(num) {};
    Tariff(const Tariff& t): title(t.title), cost(t.cost), number_subscribers(t.number_subscribers) {};

    string get_title() const {
        return title;
    }

    void set_title(string new_title) {
        title = new_title;
    }

    int get_cost() const {
        return cost;
    }

    void set_cost(int new_cost) {
        cost = new_cost;
    }

    int get_number_subscribers() const {
        return number_subscribers;
    }

    void set_number_subscribers(int new_number_subscribers) {
        number_subscribers = new_number_subscribers;
    }

    string get_string() const {
        return title + " " + to_string(cost) + " " + to_string(number_subscribers);
    }

    friend ostream&operator<<(ostream& out, const Tariff& t) {
        return out << t.title << " " << t.cost << " " << t.number_subscribers << endl;
    }

    string decode() const {
        string s = get_string();
        for(int i = 0; s[i]; ++i) {
            s[i] = char(s[i] + 1);
        }
        return s;
    }
};

class List_tariffs{
    vector <Tariff> v;
public:
    List_tariffs(){};
    List_tariffs(const List_tariffs& l): v(l.v) {};

    vector <Tariff> get_tariffs() const {
        return v;
    }

    void set_tariffs(vector <Tariff> new_v) {
        v = new_v;
    }

    void add() {
        cout << "Enter title: ";
        string title;
        cin >> title;
        cout << "Enter cost: ";
        int cost;
        cin >> cost;
        cout << "Enter number subscribers: ";
        int number_subscribers;
        cin >> number_subscribers;
        v.emplace_back(title, cost, number_subscribers);
    }

    friend ostream&operator<<(ostream& out, const List_tariffs& l) {
        for(int i = 0; i < l.v.size(); ++i) {
            out << l.v[i];
        }
        return out;
    }

    int all_subscribers() const {
        int s = 0;
        for(int i = 0; i < v.size(); ++i) {
            s += v[i].get_number_subscribers();
        }
        return s;
    }

    void Sort() {
        sort(v.begin(), v.end(), [](Tariff& L, Tariff& R) {
            return L.get_cost() < R.get_cost();
        });
    }

    void search() {
        cout << "Enter (1-3):\n1.Search by title\n2.Search by cost range\n3.Search by number subscribers range\n";
        int op;
        cin >> op;
        if(op == 1) {
            cout << "Enter title: ";
            string title;
            cin >> title;
            for(int i = 0; i < v.size(); ++i) {
                if(v[i].get_title() == title) {
                    cout << v[i];
                }
            }
        } else if(op == 2) {
            cout << "Enter cost range: ";
            int l, r;
            cin >> l >> r;
            for(int i = 0; i < v.size(); ++i) {
                if(v[i].get_cost() >= l && v[i].get_cost() <= r) {
                    cout << v[i];
                }
            }
        } else {
            cout << "Enter number subscribers range: ";
            int l, r;
            cin >> l >> r;
            for(int i = 0; i < v.size(); ++i) {
                if(v[i].get_number_subscribers() >= l && v[i].get_number_subscribers() <= r) {
                    cout << v[i];
                }
            }
        }
    }

    void print_file1() {
        cout << "Enter file name: ";
        string f;
        cin >> f;
        ofstream out(f);
        for(int i = 0; i < v.size(); ++i) {
            out << v[i];
        }
        out.close();
    }

};

int main() {
    List_tariffs l;
    for(int i = 0; i < 5; ++i) {
        l.add();
    }
    cout << l;
    cout << "Number all subscribers: " << l.all_subscribers() << endl;
    l.Sort();
    cout << l;
    l.search();
    l.print_file1();
    return 0;
}
