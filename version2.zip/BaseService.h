#pragma once
#include <iostream>

class BaseService
{
protected:

	int Price;

public:

	void setPrice(const int price);

	int getPrice() const;

};

void BaseService::setPrice(const int price)
{
	if (price >= 0)
	{
		this->Price = price;
	}
}

int BaseService::getPrice() const
{
	return this->Price;
}


