#pragma once
#include "Tariff.h"

class Client
{
private:

	std::string Name;
	Tariff m_Tariff;

public:

	Client();

	Client(const std::string name, const Tariff& tariff);

	
	void init(const std::string name, const Tariff& tariff);


	std::string getName() const;

	Tariff getTariff() const;


};

Client::Client()
{
}

Client::Client(const std::string name, const Tariff& tariff)
{
	this->Name = name;
	this->m_Tariff = tariff;
}

void Client::init(const std::string name, const Tariff& tariff)
{
	this->Name = name;
	this->m_Tariff = tariff;
}

std::string Client::getName() const
{
	return this->Name;
}

Tariff Client::getTariff() const
{
	return this->m_Tariff;
}


std::ostream& operator << (std::ostream& os, const Client& obj)
{
	os << "Client name:   " << obj.getName() << "Gb" << std::endl;
	os << obj.getTariff();
	return os;
}
