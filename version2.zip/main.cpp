﻿#include <iostream>
#include "Company.h"


void outputAllTariffs(Company& company)
{
    system("cls");
    std::vector<Tariff> temp = company.getAllTariffs();
    std::cout << "All tariffs: " << std::endl;
    for (size_t i = 0; i < temp.size(); i++)
    {
        std::cout << temp[i] << std::endl;
    }
    system("pause");
    system("cls");
}

void outputAllClients(Company& company)
{
    system("cls");
    std::vector<Client> temp = company.getAllClients();
    std::cout << "All clients: " << std::endl;
    for (size_t i = 0; i < temp.size(); i++)
    {
        std::cout << temp[i] << std::endl;
    }
    system("pause");
    system("cls");
}

void addTariff(Company& company)
{
    system("cls");
    std::cout << "     ADD TARIFF" << std::endl;

    std::string name;
    int minutes;
    int minutesPrice;
    double gb;
    int gbPrice;

    std::cin.ignore();
    std::cout << "Enter name:            ";
    std::getline(std::cin, name);


    std::cout << "Enter minutes:         ";
    std::cin >> minutes;
    std::cout << "Enter minutes price:   ";
    std::cin >> minutesPrice;
    std::cout << "Enter gb of internet:  ";
    std::cin >> gb;
    std::cout << "Enter gb price:        ";
    std::cin >> gbPrice;

    Tariff tariff(name, minutesPrice, minutes, gbPrice, gb);
    company.addTariff(tariff);

    std::cout << "Tariff was added" << std::endl;

    system("pause");
    system("cls");
}

void addClient(Company& company)
{
    system("cls");
    std::string cName;
    std::string tName;

    std::cout << "Enter client name:  ";
    std::cin.ignore();
    std::getline(std::cin, cName);

    std::vector<Tariff> temp = company.getAllTariffs();
    std::cout << "All tariffs: " << std::endl;
    for (size_t i = 0; i < temp.size(); i++)
    {
        std::cout << temp[i] << std::endl;
    }

    std::cout << "Enter tariff name: ";
    std::getline(std::cin, tName);

    for (size_t i = 0; i < temp.size(); i++)
    {
        if (tName == temp[i].getName())
        {
            company.addClient(Client(cName, temp[i]));
            std::cout << "Client was added." << std::endl;
            system("pause");
            system("cls");
            return;
        }
    }
    std::cout << "No such tariff name." << std::endl;
    system("pause");
    system("cls");
}

void findTariffByDiapazone(Company& company)
{
    system("cls");
    int minPrice;
    int maxPrice;
    int minMinutes;
    int maxMinutes;
    int minGb;
    int maxGb;
    std::cout << "Enter min price:  ";
    std::cin >> minPrice;
    std::cout << "Enter max price:  ";
    std::cin >> maxPrice;
    std::cout << "Enter min minutes:  ";
    std::cin >> minMinutes;
    std::cout << "Enter max minutes:  ";
    std::cin >> maxMinutes;
    std::cout << "Enter min gb:  ";
    std::cin >> minGb;
    std::cout << "Enter max gb:  ";
    std::cin >> maxGb;

    std::vector<Tariff> result = company.findTariffs(minPrice, maxPrice, minMinutes, maxMinutes, minGb, maxGb);
    std::cout << "\nResult tariffs: " << std::endl;
    for (size_t i = 0; i < result.size(); i++)
    {
        std::cout << result[i] << std::endl;
    }
    system("pause");
    system("cls");
}

void outputTotalClientsQuantity(Company& company)
{
    system("cls");
    std::cout << "Total clients quantity:  " << company.getAllClients().size() << std::endl;    
    system("pause");
    system("cls");
}


void menu(Company& company)
{
    while (true)
    {
        std::cout << "     Menu" << std::endl;
        std::cout << "1 - output all tariffs" << std::endl;
        std::cout << "2 - output all clients" << std::endl;
        std::cout << "3 - add tariff" << std::endl;
        std::cout << "4 - add client" << std::endl;
        std::cout << "5 - find tariff by diapazone" << std::endl;
        std::cout << "6 - output total clients quantity" << std::endl;
        std::cout << "else - exit" << std::endl;
        int choise;
        std::cout << "Your choise:  ";
        std::cin >> choise;

        if (choise == 1)
        {
            outputAllTariffs(company);
        }
        else if (choise == 2)
        {
            outputAllClients(company);
        }
        else if (choise == 3)
        {
            addTariff(company);
        }
        else if (choise == 4)
        {
            addClient(company);
        }
        else if (choise == 5)
        {
            findTariffByDiapazone(company);
        }
        else if (choise == 6)
        {
            outputTotalClientsQuantity(company);
        }
        else 
        {
            std::cout << "Nenu exit." << std::endl;
            return;
        }
    }
}


int main()
{
    Company company;

    Tariff tr1("tariff1", 50, 100, 100, 20);
    Tariff tr2("tariff2", 20, 30, 50, 10);
    Tariff tr3("tariff3", 100, 300, 150, 50);

    company.addTariff(tr1);
    company.addTariff(tr2);
    company.addTariff(tr3);


    company.addClient(Client("Client1", tr1));
    company.addClient(Client("Client2", tr3));
    company.addClient(Client("Client3", tr2));
    company.addClient(Client("Client4", tr1));

    menu(company);

    return 0;   
}

