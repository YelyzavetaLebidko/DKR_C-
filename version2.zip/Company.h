#pragma once
#include <vector>
#include "Client.h"


class Company
{
private:

	std::vector<Tariff> Tariffs;
	std::vector<Client> Clients;

public:

	Company();


	void addTariff(const Tariff& tariff);

	std::vector<Tariff> getAllTariffs() const;


	void addClient(const Client& client);	

	std::vector<Client> getAllClients() const;

	std::vector<Tariff> findTariffs(const int min_price, const int max_price, const int min_minutes, const int max_minutes, const double min_gb, const double max_gb) const;

};


Company::Company()
{
	
}

void Company::addTariff(const Tariff& tariff)
{
	int index = 0;
	while (index < this->Tariffs.size() && this->Tariffs[index].getTotalPrice() < tariff.getTotalPrice())
	{
		index++;
	}
	this->Tariffs.insert(this->Tariffs.begin() + index, tariff);
}

std::vector<Tariff> Company::getAllTariffs() const
{
	return this->Tariffs;
}

void Company::addClient(const Client& client)
{
	this->Clients.push_back(client);
}

std::vector<Client> Company::getAllClients() const
{
	return this->Clients;
}

std::vector<Tariff> Company::findTariffs(const int min_price, const int max_price, const int min_minutes, const int max_minutes, const double min_gb, const double max_gb) const
{
	std::vector<Tariff> result;
	for (size_t i = 0; i < this->Tariffs.size(); i++)
	{
		if (this->Tariffs[i].getTotalPrice() >= min_price &&
			this->Tariffs[i].getTotalPrice() <= max_price &&
			this->Tariffs[i].getCalls().getMinutes() >= min_minutes &&
			this->Tariffs[i].getCalls().getMinutes() <= max_minutes &&
			this->Tariffs[i].getInternet().getGB() >= min_gb &&
			this->Tariffs[i].getInternet().getGB() <= max_gb)
		{
			result.push_back(this->Tariffs[i]);
		}
	}
	return result;
}
